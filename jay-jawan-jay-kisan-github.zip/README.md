# Jay Jawan Jay Kisan 🌾

यह एक सरल HTML वेबसाइट है जो भारत में प्रमुख फसलों की जानकारी देती है — जैसे गेहूं, धान, मक्का और गन्ना।

## विशेषताएँ:
- हर फसल के लिए मौसम, तापमान, बुवाई और कटाई की जानकारी
- सर्च बार से फसलें फ़िल्टर करो
- मोबाइल फ्रेंडली और responsive डिज़ाइन

## डिप्लॉयमेंट:
GitHub Pages पर होस्ट करने के लिए:

```bash
git init
git remote add origin https://github.com/ajeet12a/jay-jawan-jay-kisan.git
git add .
git commit -m "Initial commit"
git push -u origin main
```

फिर GitHub Pages में जाकर `main` branch को root के रूप में सेट कर दो।

वेबसाइट live होगी:  
`https://ajeet12a.github.io/jay-jawan-jay-kisan/`
