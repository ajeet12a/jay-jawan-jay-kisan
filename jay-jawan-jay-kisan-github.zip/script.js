// script.js

console.log("Jay Jawan Jay Kisan website loaded.");

const searchInput = document.getElementById("searchInput");
const cropList = document.getElementById("cropList");
const crops = cropList.getElementsByClassName("crop");

searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();

  Array.from(crops).forEach(crop => {
    const title = crop.querySelector("h2").textContent.toLowerCase();
    if (title.includes(query)) {
      crop.style.display = "block";
    } else {
      crop.style.display = "none";
    }
  });
});
